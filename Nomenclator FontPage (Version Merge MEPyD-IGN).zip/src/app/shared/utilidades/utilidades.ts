export enum enumTipoContenido {
  Imagen = 1,
  Pdf = 5

}

export enum enumEstado {
  Completado = 6

}
export enum enumParametrosSistema {
  Contenido = 1

}
export enum enumContenUser {
  id = 1
}
export enum enumParametro {
  ContenidoUsuarioFinal = 1,
  distriMunicipal=2,
  seccion=3,
  paraje=4,
  barrio=5,
  subbarrio=6
  }
