export interface Estados{
  descripcion: string;
  id: number;
}
