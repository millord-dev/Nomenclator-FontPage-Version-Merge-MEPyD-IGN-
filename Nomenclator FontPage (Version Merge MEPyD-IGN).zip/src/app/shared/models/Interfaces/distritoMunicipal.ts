export interface DistritoMunicipal{
  municipioId: number,
  key: string,
  codigoOne: string,
  nombre: string,
  id: number
}
