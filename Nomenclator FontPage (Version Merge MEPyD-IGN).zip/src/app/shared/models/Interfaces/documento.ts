export interface Documento{
  Descripcion: string;

}
