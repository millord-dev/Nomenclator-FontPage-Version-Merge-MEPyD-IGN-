export interface HistorialNombresLocales {

    id?: number;
    objetoId?: number;
    nombreLocal: string;
    estatus?:boolean;
    creadoEn?: string;
    creadoPor?:number;
    modificadoPor?:number;
    modificadoEn?:string;
  }
