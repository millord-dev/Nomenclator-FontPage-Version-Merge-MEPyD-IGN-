export interface SubClaseObjeto{
  claseObjetoId: number,
  nombre: string,
  estatus: boolean,
  id: number
}
