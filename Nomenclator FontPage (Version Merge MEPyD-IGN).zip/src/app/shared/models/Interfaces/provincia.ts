export interface Provincia{
  regionId: number;
  codigoOne: string;
  key: string;
  nombre: string;
  id: number;
}
