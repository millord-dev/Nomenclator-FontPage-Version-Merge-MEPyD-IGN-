export interface HistorialNombresHistoricos {

    id?: number;
    objetoId?: number;
    nombreHistorico: string;
    estatus?:boolean;
    creadoEn?: string;
    creadoPor?:number;
    modificadoPor?:number;
    modificadoEn?:string;
  }
