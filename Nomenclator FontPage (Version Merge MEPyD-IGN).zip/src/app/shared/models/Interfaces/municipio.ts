export interface Municipio{
  provinciaId: number,
  codigoOne: string,
  key: string,
  nombre: string,
  id: number
}
