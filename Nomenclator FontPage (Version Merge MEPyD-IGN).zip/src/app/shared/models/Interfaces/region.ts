export interface Region{
  codigoOne: string;
  key: string;
  nombre: string;
  id: number;
}
