export interface Filter{
  nombreGeografico:String,
  nombreLocal:String,
  claseObjetoId: string,
  subClaseObjetoId: string,
  regionId: string,
  provinciaId: string,
  municipioId: string,
  distritoMunicipalId: string
}
